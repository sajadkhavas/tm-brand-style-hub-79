const express = require('express');
const { Category, Product } = require('../models');

const router = express.Router();

// Get all categories (with optional includeInactive param)
router.get('/', async (req, res) => {
  try {
    const { includeInactive } = req.query;
    
    const where = {};
    if (!includeInactive) {
      where.isActive = true;
    }

    const categories = await Category.findAll({
      where,
      order: [['order', 'ASC'], ['name', 'ASC']],
      attributes: ['id', 'name', 'nameEn', 'slug', 'description', 'image', 'icon', 'isActive', 'order']
    });

    res.json({ data: categories });
  } catch (error) {
    console.error('Get categories error:', error);
    res.status(500).json({ error: 'Failed to fetch categories' });
  }
});

// Get single category with products
router.get('/:slug', async (req, res) => {
  try {
    const category = await Category.findOne({
      where: { slug: req.params.slug, isActive: true },
      attributes: ['id', 'name', 'nameEn', 'slug', 'description', 'image', 'icon'],
      include: [{
        model: Product,
        as: 'products',
        where: { isActive: true },
        required: false
      }]
    });

    if (!category) {
      return res.status(404).json({ error: 'Category not found' });
    }

    res.json({ data: category });
  } catch (error) {
    console.error('Get category error:', error);
    res.status(500).json({ error: 'Failed to fetch category' });
  }
});

module.exports = router;
