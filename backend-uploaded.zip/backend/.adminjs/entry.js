AdminJS.UserComponents = {}
import richText from '../src/admin/components/RichText'
AdminJS.UserComponents.richText = richText
import dashboard from '../src/admin/components/Dashboard'
AdminJS.UserComponents.dashboard = dashboard
import reorder from '../src/admin/components/Reorder'
AdminJS.UserComponents.reorder = reorder
import UploadEditComponent from '../node_modules/@adminjs/upload/build/features/upload-file/components/UploadEditComponent'
AdminJS.UserComponents.UploadEditComponent = UploadEditComponent
import UploadListComponent from '../node_modules/@adminjs/upload/build/features/upload-file/components/UploadListComponent'
AdminJS.UserComponents.UploadListComponent = UploadListComponent
import UploadShowComponent from '../node_modules/@adminjs/upload/build/features/upload-file/components/UploadShowComponent'
AdminJS.UserComponents.UploadShowComponent = UploadShowComponent